const pino = require('pino');
const logger = pino({ level: 'silent' });
module.exports default logger;